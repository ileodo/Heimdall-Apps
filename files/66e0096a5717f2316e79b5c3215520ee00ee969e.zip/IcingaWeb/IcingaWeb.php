<?php namespace App\SupportedApps\IcingaWeb;

class IcingaWeb extends \App\SupportedApps
{
}
