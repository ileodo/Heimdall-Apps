<?php namespace App\SupportedApps\Synology;

class Synology extends \App\SupportedApps
{
}
