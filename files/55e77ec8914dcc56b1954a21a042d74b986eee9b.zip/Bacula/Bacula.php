<?php namespace App\SupportedApps\Bacula;

class Bacula extends \App\SupportedApps
{
}
