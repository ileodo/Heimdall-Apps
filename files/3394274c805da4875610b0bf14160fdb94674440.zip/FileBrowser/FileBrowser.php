<?php namespace App\SupportedApps\FileBrowser;

class FileBrowser extends \App\SupportedApps
{
}
