<?php namespace App\SupportedApps\Wikijs;

class Wikijs extends \App\SupportedApps
{
}
