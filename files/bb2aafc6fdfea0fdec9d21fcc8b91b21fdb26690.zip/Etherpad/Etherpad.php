<?php namespace App\SupportedApps\Etherpad;

class Etherpad extends \App\SupportedApps {

}