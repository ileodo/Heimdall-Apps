<?php namespace App\SupportedApps\SickGear;

class SickGear extends \App\SupportedApps
{
}
