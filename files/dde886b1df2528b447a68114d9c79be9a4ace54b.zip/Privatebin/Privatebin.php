<?php namespace App\SupportedApps\Privatebin;

class Privatebin extends \App\SupportedApps
{
}
