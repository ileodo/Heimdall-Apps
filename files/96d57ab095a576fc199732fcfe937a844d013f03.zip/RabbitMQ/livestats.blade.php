<ul class="livestats">
    <li>
        <span class="title">Messages</span>
        <strong>{!! $total !!}</strong>
    </li>
    <li>
        <span class="title">In / Out</span>
        <strong>{!! $in !!} / {!! $out !!}</strong>
    </li>
</ul>
