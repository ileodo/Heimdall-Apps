<?php namespace App\SupportedApps\ioBroker;

class ioBroker extends \App\SupportedApps
{
}
