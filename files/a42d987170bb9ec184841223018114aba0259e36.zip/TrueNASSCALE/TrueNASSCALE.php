<?php namespace App\SupportedApps\TrueNASSCALE;

class TrueNASSCALE extends \App\SupportedApps {

}