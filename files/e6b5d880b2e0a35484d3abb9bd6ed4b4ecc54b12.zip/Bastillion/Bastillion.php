<?php namespace App\SupportedApps\Bastillion;

class Bastillion extends \App\SupportedApps
{
}
