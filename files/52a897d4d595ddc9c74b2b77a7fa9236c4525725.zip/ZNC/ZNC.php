<?php namespace App\SupportedApps\ZNC;

class ZNC extends \App\SupportedApps
{
}
