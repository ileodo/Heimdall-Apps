<ul class="livestats">
    <li>
        <span class="title">Next</span>
        <strong>{!! $nextBackup !!}</strong>
    </li>
    <li>
        <span class="title">Errors</span>
        <strong>{!! $error !!}</strong>
    </li>
</ul>
