<?php namespace App\SupportedApps\Zabbix;

class Zabbix extends \App\SupportedApps
{
}
