<?php namespace App\SupportedApps\Harbor;

class Harbor extends \App\SupportedApps
{
}
