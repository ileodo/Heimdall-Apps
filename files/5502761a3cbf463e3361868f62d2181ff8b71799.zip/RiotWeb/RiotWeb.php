<?php namespace App\SupportedApps\RiotWeb;

class RiotWeb extends \App\SupportedApps
{
}
